export interface IMappingConfig {
    labelKey: string;
    valueKey: string;
}