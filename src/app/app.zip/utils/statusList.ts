export const status_list = [
    { id:1013, name: 'Draft'},
    { id:1014, name: 'Active' },
    { id:1015, name: 'Inactive' },
    { id:1016, name: 'Suspended' },
  ];