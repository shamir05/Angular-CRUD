export const actions = {
    add: 'Add',
    edit: 'Update',
    view: 'View',
    delete: 'Delete',
  };