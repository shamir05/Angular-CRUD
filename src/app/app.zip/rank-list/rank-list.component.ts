import { Component } from '@angular/core';
import { MenuItem, MessageService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { RankFormComponent } from './rank-form/rank-form.component';
import { RankService } from '../Services/rank.service';
import { getSeverity } from '../utils/Severity';
import { DialogConfig } from '../utils/dialogForm.model'
import { actions } from '../utils/actions';
import { getInventoryStatus } from '../utils/getInventoryStatus';

@Component({
  selector: 'app-rank-list',
  templateUrl: './rank-list.component.html',
  styleUrls: ['./rank-list.component.scss'],
})

export class RankListComponent {
  dropdownmenuTable: MenuItem[] = [];
  ref?: DynamicDialogRef;
  showRanks: any[] = [];
  Eactions = actions;
  getSeverity = getSeverity;
  getInventoryStatus = getInventoryStatus
  // Define columns configuration
  cols = [
    { field: 'title', header: 'Title' },
    { field: 'description', header: 'Description' },
    { field: 'rankType', header: 'Rank Type' },
    { field: 'organization', header: 'Organization' },
    { field: 'shortCode', header: 'Short Code' },
    { field: 'scale', header: 'Scale' },
  ];

  constructor(
    public dialogService: DialogService,
    private rankService: RankService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    this.getRanks();
  }

  // Show a message to the user
  showMessage(severity: string, summary: string, detail: string) {
    this.messageService.add({severity, summary, detail});
  }

  // Generate menu items for the dropdown
  getMenuItems(rowData: any): MenuItem[] {
    return [
      {label: 'Edit', command: () => this.showRankForm(this.Eactions.edit, rowData)},
      {label: 'View', command: () => this.showRankForm(this.Eactions.view, rowData)},
      {label: 'Delete', command: () => this.showRankForm(this.Eactions.delete, rowData)},
    ]};

  // Open the rank form for adding a new rank
  showRankForm(action: any, rankData?: any) {
    const dialogConfig = new DialogConfig(`${action} Rank`, rankData);
    this.ref = this.dialogService.open(RankFormComponent, {
      
      ...dialogConfig,
    });
    this.ref.onClose.subscribe((result: boolean) => {
      if (result) this.getRanks();
    });
  }

  // Fetch ranks from the service and map them to the display structure
  getRanks() {
    let payLoad = {}
    this.rankService.handleRank(payLoad).subscribe((response) => {
      if (response?.data?.[0]?.[0]) {
        const ranksArray = response.data[0][0];
        this.showRanks = ranksArray.map((rank: any) => ({
          ...rank,
          rankType: rank.rankTypeId?.title,
          organization: rank.organizationTypeId?.title,
          inventoryStatus: this.getInventoryStatus(rank.statusId)
        }));
      }
    });
  }  
}
