import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { CityFormComponent } from './city-form/city-form.component';

@Component({
  selector: 'app-city-list',
  templateUrl: './city-list.component.html',
  styleUrls: ['./city-list.component.scss']
})
export class CityListComponent {
  dropdownmenuTable: MenuItem[] = [];

  // for closeing on close button
  ngOnInit() {
    this.dropdownmenuTable = [
      {
        label: 'Update',
      },
      {
        label: 'Delete',
      }
    ];

  }
  constructor(public dialogService: DialogService, private ref: DynamicDialogRef) {

  }
  showCityForm() {
    this.ref = this.dialogService.open(CityFormComponent, {

      header: 'Add City',
      width: '70%',
      contentStyle: { overflow: 'auto' },
      styleClass: 'png-dialogbox',
      baseZIndex: 10000,
      maximizable: true,
      closable: true,
      footer: '.'
    });
  }

  // Define columns configuration
  cols = [
    { field: 'cityName', header: 'City Name' },
    { field: 'timeZone', header: 'Time Zone' },
    { field: 'countryName', header: 'Country Name' },
    { field: 'description', header: 'Description' },


  ];

  city_values_list = [
    {
      cityName: 'Rawalpindi',
      timeZone: 'GMT+5',
      countryName: 'Pakistan',
      description: 'CSD HPBC ONLINE SHOP RAWALPIND',
      inventoryStatus: 'Draft',
    },
    {
      cityName: 'Rawalpindi',
      timeZone: 'GMT+5',
      countryName: 'Pakistan',
      description: 'CSD HPBC ONLINE SHOP RAWALPIND',
      inventoryStatus: 'Active',
    },
    {
      cityName: 'Islamabad',
      timeZone: 'GMT+5',
      countryName: 'Pakistan',
      description: 'CSD HPBC ONLINE SHOP Islamabad',
      inventoryStatus: 'Inactive',
    },
    {
      cityName: 'Islamabad',
      timeZone: 'GMT+5',
      countryName: 'Pakistan',
      description: 'CSD HPBC ONLINE SHOP Islamabad',
      inventoryStatus: 'Suspended',
    },
  ];

  // Method to determine the severity based on inventory status
  getSeverity(status: string): string {
    switch (status) {
      case 'Active':
        return 'success';
      case 'Inactive':
        return 'warning';
      case 'Suspended':
        return 'info';
      case 'Draft':
        return 'info';
      default:
        return '';
    }
  }
}
