import { Component } from '@angular/core';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { AnonymousSubject } from 'rxjs/internal/Subject';


@Component({
  selector: 'app-city-form',
  templateUrl: './city-form.component.html',
  styleUrls: ['./city-form.component.scss']
})
export class CityFormComponent {

  country_name_list = [
    { name: 'Pakistan' },
    { name: 'Pakistan 2' },
  ];
  status_list = [
    { name: 'Draft' },
    { name: 'Suspended' },
    { name: 'Inactive' },
    { name: 'Active' },
  ];



  // for closeing on close button
  constructor(public dialogService: DialogService, private ref: DynamicDialogRef) {

  }

  onClose() {
    this.ref.close();
  }

  translate(label:any) {
    // return this.multiService.verifyLabel(label) as string;
    return label;
  }

}
